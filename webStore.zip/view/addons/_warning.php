<div class="<?php echo $warningType;?>">
  <?php echo $warning;?>
</div>
