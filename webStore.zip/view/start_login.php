<?php
require_once __DIR__ . '/_header.php'; 
?>


<div class="loginModal">Login <?php echo $succesVar; ?>. Redirecting...</div>