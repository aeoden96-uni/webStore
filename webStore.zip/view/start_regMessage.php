<?php
require_once __DIR__ . '/_header.php'; 
?>

<div class="loginModal">
<?php echo $response; ?>
<br>
<a href="index.php?rt=start">Return</a>
</div>