<!DOCTYPE html>
<html>
<head>
	<meta charset="utf8">
	<title>ShopApp</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<a href="index.php?rt=main/main"><h1><?php echo  $title; ?></h1></a>


	